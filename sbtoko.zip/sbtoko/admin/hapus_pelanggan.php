<?php
// Koneksi ke database (asumsikan $koneksi sudah ada)
include 'koneksi.php';

// Ambil ID pelanggan dari parameter URL
$id_pelanggan = $_GET['id'];

// Query untuk menghapus pelanggan
$hapus = $koneksi->query("DELETE FROM pelanggan WHERE id_pelanggan = '$id_pelanggan'");

// Redirect kembali ke halaman data pelanggan setelah menghapus
header("location: data_pelanggan.php");
?>
