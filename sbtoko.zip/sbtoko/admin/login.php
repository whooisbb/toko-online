<?php
session_start();
// skrip koneksi
$koneksi = new mysqli("localhost", "root", "", "sbtoko");

if (isset($_POST['login'])) {
    $user = $_POST['user'];
    $pass = $_POST['pass'];

    // Use prepared statements to prevent SQL injection
    $query = $koneksi->prepare("SELECT * FROM admin WHERE username=? AND password=?");
    $query->bind_param("ss", $user, $pass);
    $query->execute();
    
    $result = $query->get_result();
    $yangcocok = $result->num_rows;

    if ($yangcocok == 1) {
        $_SESSION['admin'] = $result->fetch_assoc();
        echo "<div class='alert alert-info'>Login sukses</div>";
        echo "<meta http-equiv='refresh' content='1;url=index.php'>";
    } else {
        echo "<div class='alert alert-danger'>Login gagal</div>";
    }

    $query->close();
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Bootstrap Admin Template: Binary Admin</title>

    <!-- BOOTSTRAP STYLES -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLES -->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>

<body>
    <div class="container">
        <div class="row text-center">
            <div class="col-md-12">
                <br /><br />
                <h2> Setia Bhakti: Login</h2>
                <h5>( Login yourself to get access )</h5>
                <br />
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-4 col-sm-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong> Enter Details To Login </strong>
                    </div>
                    <div class="panel-body">
                        <form  role="form" method="post">
                            <br />
                            <div class="form-group input-group">
                                <span class="input-group-addon"><i class="fa fa-tag"></i></span>
                                <input type="text" class="form-control" name="user" />
                            </div>
                            <div class="form-group input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="password" class="form-control" name="pass" />
                            </div>
                            <div class="form-group">
                                <label class="checkbox-inline">
                                    <input type="checkbox" /> Remember me
                                </label>
                                <span class="pull-right">
                                    <a href="#">Forget password ?</a>
                                </span>
                            </div>
                            <button class="btn btn-primary" name="login">Login</button>
                            <hr />
                            Not registered? <a href="registration.html">Click here</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</body>

</html>
