<?php
session_start();
include 'koneksi.php';

// Jika tidak ada session pelanggan (belum login), maka arahkan ke login.php
if (!isset($_SESSION['pelanggan'])) {
    echo "<script>alert('Silahkan login terlebih dahulu.');</script>";
    echo "<script>location='login.php';</script>";
    exit(); // Added exit to stop further execution
}

?>

<!DOCTYPE html>
<html>

<head>
    <title>Checkout</title>
    <link rel="stylesheet" type="text/css" href="admin/assets/css/bootstrap.css">
</head>

<body>
  <?php include 'menu.php';  ?>

    <section class="konten">
        <div class="container">
            <h1>Keranjang Belanja</h1>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Subharga</th>
                    </tr>
                </thead>
               <tbody>
    <?php
    $totalbelanja = 0;

    // Check if $_SESSION['keranjang'] is set and is an array
    if (isset($_SESSION['keranjang']) && is_array($_SESSION['keranjang'])) {
        $nomor = 1; // Reset the numbering
        foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) 
        {
            // mendapatkan data produk berdasarkan id produk
            $ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk'");
            $perproduk = $ambil->fetch_assoc();

            $nama = $perproduk['nama_produk'];
            $harga = $perproduk['harga'];
            $berat = $perproduk['berat'];

            $subberat = $berat * $jumlah;
            $subharga = $harga * $jumlah;

            // Menambahkan data ke tabel pembelian_produk
            $koneksi->query("INSERT INTO pembelian_produk(id_pembelian, id_produk, nama, harga, berat, subberat, subharga, jumlah) 
                             VALUES ('$id_produk', '$nama', '$harga', '$berat', '$subberat', '$subharga', '$jumlah')");

            ?>
            <tr>
                <td><?php echo $nomor++; ?></td>
                <td><?php echo $nama; ?></td>
                <td>Rp. <?php echo number_format($harga); ?></td>
                <td><?php echo $jumlah; ?></td>
                <td>Rp. <?php echo number_format($subharga); ?></td>
            </tr>
            <?php
            $totalbelanja += $subharga;
        } // Akhir dari foreach
    } else {
        echo '<tr><td colspan="5">Keranjang belanja kosong</td></tr>';
    }
    ?>
</tbody>
                <tfoot>
                    <tr>
                        <th colspan="4">Total Belanja</th>
                        <th>Rp. <?php echo number_format($totalbelanja); ?></th>
                    </tr>
                </tfoot>
            </table>

            <form method="post">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Nama Pelanggan</label>
                            <input type="text" class="form-control" readonly value="<?php echo isset($_SESSION['pelanggan']['nama_pelanggan']) ? $_SESSION['pelanggan']['nama_pelanggan'] : ''; ?>">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label>No Telepon</label>
                            <input type="text" class="form-control" readonly value="<?php echo isset($_SESSION['pelanggan']['telepon_pelanggan']) ? $_SESSION['pelanggan']['telepon_pelanggan'] : ''; ?>">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Ongkos Kirim</label>
                            <select class="form-control" name="id_ongkir">
                                <option value="">Pilih ongkos kirim </option>
                                <?php
                                $ambil =  $koneksi->query("SELECT * FROM ongkir");
                                while($perongkir = $ambil->fetch_assoc()){
                                ?>
                                <option value="<?php echo $perongkir["id_ongkir"] ?>">
                                    <?php echo $perongkir['nama_kota'] . ' ' . number_format($perongkir['tarif']); ?>
                                </option>
                                <?php }?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Alamat Lengkap Pengiriman</label>
                        <textarea class="form-control" name="alamat_pengiriman" placeholder="masukan alamat lengkap pengiriman(termasuk kode pos)"></textarea>
                    </div>

                    <div class="col-md-12">
                        <button class="btn btn-primary" name="checkout">Checkout</button>
                    </div>
                </div>
            </form>

            <?php  
            // Initialize $id_pembelian_barusan
            $id_pembelian_barusan = 0;

            if (isset($_POST["checkout"])) 
            {
                $id_pelanggan = isset($_SESSION['pelanggan']['id_pelanggan']) ? $_SESSION['pelanggan']['id_pelanggan'] : '';
                $id_ongkir = $_POST['id_ongkir'];
                $tanggal_pembelian = date("Y-m-d");
                $alamat_pengiriman = $_POST['alamat_pengiriman'];

                $ambil = $koneksi->query("SELECT * FROM ongkir WHERE id_ongkir='$id_ongkir'");
                $arrayongkir = $ambil->fetch_assoc();
                $nama_kota = $arrayongkir['nama_kota'];
                $tarif = $arrayongkir['tarif'];

                if ($arrayongkir) {
                    $tarif = $arrayongkir['tarif'];
                    $total_pembelian = $totalbelanja + $tarif;

                    // 1. Menyimpan data ke tabel pembelian 
                    $koneksi->query("INSERT INTO pembelian (id_pelanggan, id_ongkir, tanggal_pembelian, total_pembelian,nama_kota,tarif,alamat_pengiriman) 
                                    VALUES ('$id_pelanggan', '$id_ongkir', '$tanggal_pembelian', '$total_pembelian','$nama_kota','$tarif','$alamat_pengiriman')");

                    // 2. Mendapatkan id_pembelian barusan terjadi
                    $id_pembelian_barusan = $koneksi->insert_id;

                    // 3. Menyimpan data ke tabel pembelian_produk
                    foreach ($_SESSION["keranjang"] as $id_produk => $jumlah) { 
                        $koneksi->query("INSERT INTO pembelian_produk (id_pembelian, id_produk, jumlah)
                                        VALUES ('$id_pembelian_barusan', '$id_produk', '$jumlah')");
                    }

                    // 4. Tampilkan dialihkan ke nota, nota dari pembelian barusan 
                    echo "<script>alert('Pembelian sukses');</script>";
                    echo "<script>location='nota.php?id=$id_pembelian_barusan';</script>";
                } else {
                    echo "Error: Ongkos kirim tidak ditemukan.";
                }
            } 
            ?>
        </div>
    </section>

    <pre><?php print_r($_SESSION['pelanggan']); ?></pre>
    <pre><?php print_r($_SESSION["keranjang"]); ?></pre>

</body>

</html>
