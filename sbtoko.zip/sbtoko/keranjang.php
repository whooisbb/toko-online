<?php
session_start();

echo "<pre>";
print_r($_SESSION['keranjang']);
echo "</pre>";

include 'koneksi.php';

if (empty($_SESSION['keranjang'])) {
    echo "<script>alert('Keranjang kosong, silahkan belanja dulu');</script>";
    echo "<script>location='index.php';</script>";
    exit();
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Checkout</title>
    <link rel="stylesheet" href="admin/assets/css/bootstrap.css">
</head>

<body>

<?php include 'menu.php';  ?>

    <section class="konten">
        <div class="container">
            <h1>Checkout</h1>
            <div class="row">
                <div class="col-md-6">
                    <!-- Form for customer details -->
                    <form method="post">
                        <div class="form-group">
                            <label>Nama Pelanggan</label>
                            <input type="text" class="form-control" readonly value="<?php echo $_SESSION['pelanggan']['nama_pelanggan']; ?>">
                        </div>
                        <div class="form-group">
                            <label>No Telepon</label>
                            <input type="text" class="form-control" readonly value="<?php echo $_SESSION['pelanggan']['telepon_pelanggan']; ?>">
                        </div>

                        <!-- Table to display items in the cart -->
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Barang</th>
                                    <th>Harga</th>
                                    <th>Jumlah</th>
                                    <th>Subtotal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $totalbelanja = 0;
                                $nomor = 1;

                                foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
                                    // mendapatkan data produk berdasarkan id produk
                                    $ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk'");
                                    $perproduk = $ambil->fetch_assoc();

                                    $nama = $perproduk['nama_produk'];
                                    $harga = $perproduk['harga'];

                                    $subharga = $harga * $jumlah;
                                    $totalbelanja += $subharga;
                                    ?>
                                    <tr>
                                        <td><?php echo $nomor++; ?></td>
                                        <td><?php echo $nama; ?></td>
                                        <td>Rp. <?php echo number_format($harga); ?></td>
                                        <td><?php echo $jumlah; ?></td>
                                        <td>Rp. <?php echo number_format($subharga); ?></td>
                                        <td><a href="hapuskeranjang.php?id=<?php echo $id_produk; ?>" class="btn btn-danger">Hapus</a></td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="4">Total Belanja</th>
                                    <th>Rp. <?php echo number_format($totalbelanja); ?></th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>

                        <!-- Add more customer details if needed -->

                        <!-- Add your checkout content here (e.g., order summary, payment options, etc.) -->

                        <a href="checkout.php" class="btn btn-primary" name="checkout">Checkout</button>
                    </form>
                    
                    <!-- "Lanjutkan Belanja" button -->
                    <a href="index.php" class="btn btn-success">Lanjutkan Belanja</a>
                </div>
                <div class="col-md-6">
                    <!-- Add additional content or summary on the right side -->
                </div>
            </div>
        </div>
    </section>

</body>
</html>
