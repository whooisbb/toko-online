<?php
session_start();
include 'koneksi.php';?>

<!DOCTYPE html>
<html>

<head>
    <title>Nota Pembelian</title>
    <link rel="stylesheet" type="text/css" href="admin/assets/css/bootstrap.css">
</head>

<body>

    <?php include 'menu.php'; ?>
    <section class="konten">
        <div class="container">
            <!-- nota disini copas aja nota yang ada di admin -->
            <h2>Detail Pembelian</h2>
            <?php
            $ambil = $koneksi->query("SELECT * FROM pembelian 
                JOIN pelanggan ON pembelian.id_pelanggan = pelanggan.id_pelanggan 
                JOIN ongkir ON pembelian.id_ongkir = ongkir.id_ongkir
                WHERE pembelian.id_pembelian='$_GET[id]'");
            $detail = $ambil->fetch_assoc();
            ?>
            <h1>Data Orang Yang beli $detail </h1>
            <pre><?php print_r($detail); ?></pre>

            <h1>Data Orang Yang Login di session</h1>
            <pre><?php print_r($_SESSION) ?></pre>

            <!--- jika pelanggan yg beli tidak sama dgn pelanggan yg login, maka di larikan ke riwayat.php karana tdk berhak melihat nota org lain -->

            <!-- pelanggan yang  beli harus pelanggan yang login -->
            <?php
            // mendapatkan id_pelanggan yg beli 
            $idpelangganyangbeli = $detail['id_pelanggan'];

            // mendapatkan id_pelanggan yang login 
            $idpelangganyanglogin = $_SESSION['pelanggan'] ['id_pelanggan'];

            if ($idpelangganyangbeli!==$idpelangganyanglogin)
             {
                  echo "<script>alert('JANGAN NAKAL SU!');</script>";
                   echo "<script>location='riwayat.php';</script>";
             } 
            ?>

            <div class="row">
                <div class="col-md-4">
                    <h3>Pembelian</h3>
                    <strong>No. Pembelian: <?php echo $detail['id_pembelian'] ?></strong><br>
                    Tanggal: <?php echo $detail['tanggal_pembelian']; ?><br>
                    Total: Rp. <?php echo number_format($detail['total_pembelian']); ?>
                </div>
                <div class="col-md-4">
                    <h3>Pelanggan</h3>
                    <strong><?php echo $detail['nama_pelanggan']; ?></strong> <br>
                    <p>
                        <?php echo $detail['telepon_pelanggan']; ?> <br>
                        <?php echo $detail['email']; ?>
                    </p>
                </div>
                <div class="col-md-4">
                    <h3>Pengiriman</h3>
                    <strong><?php echo $detail['nama_kota'] ?></strong>
                    Ongkos Kirim: Rp. <?php echo number_format($detail['tarif']); ?><br>
                    Alamat: <?php echo $detail['alamat_pengiriman']; ?>
                </div>
            </div>


            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Subberat</th>
                        <th>Subharga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $nomor = 1;
                    $ambil_produk = $koneksi->query("SELECT * FROM pembelian_produk 
                    JOIN produk ON pembelian_produk.id_produk = produk.id_produk 
                    WHERE pembelian_produk.id_pembelian='$_GET[id]'");
                    while ($pecah = $ambil_produk->fetch_assoc()) {
                    ?>
                        <tr>
                            <td><?php echo $nomor; ?></td>
                            <td><?php echo $pecah['nama_produk']; ?></td>
                            <td>Rp. <?php echo number_format($pecah['harga']); ?></td>
                            <td><?php echo $pecah['jumlah']; ?></td>
                            <td><?php echo $pecah['subberat']; ?> Gr.</td>
                            <td>Rp. <?php echo number_format($pecah['subharga']); ?></td>
                        </tr>
                    <?php
                        $nomor++;
                    }
                    ?>
                </tbody>
            </table>

            <div class="col-md-7">
                <div class="alert alert-info">
                    <p>
                        Silahkan melakukan pembayaran Ke <br>
                        <strong>BANK BCA 012-0200-1102 AN.Bambang Irwasyah</strong>
                    </p>
                </div>
            </div>
        </div>
    </section>
</body>

</html>
